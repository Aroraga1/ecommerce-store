const Checkout = () => {
  return (
    <div style={{ padding: "2rem" }}>
      <h2>Checkout</h2>
      {/* Checkout form and payment integration will go here */}
    </div>
  );
};

export default Checkout;
