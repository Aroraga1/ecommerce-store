const Success = () => {
  return (
    <div style={{ textAlign: "center", marginTop: "3rem" }}>
      <h2>Thank you for your purchase!</h2>
      <p>Your order has been placed successfully.</p>
    </div>
  );
};

export default Success;
